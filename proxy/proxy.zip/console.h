#ifndef _CONSOLE_H
#define _CONSOLE_H

void show_info(char* msg, char* iface);

void init_console();

int ctl_iface();

#endif
